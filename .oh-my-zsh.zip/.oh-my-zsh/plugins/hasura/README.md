# Hasura plugin

This plugin adds completion for [the Hasura CLI](https://hasura.io/docs/latest/hasura-cli/index/).

To use it, add `hasura` to the plugins array in your zshrc file:

```zsh
plugins=(... hasura)
```
