alias pylint-quick='pylint --reports=n'
